package vista;

import controlador.Snacks;
import controlador.SnacksLoader;
import controlador.ComprasController;
import modelo.Compras;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.net.URL;
import java.util.List;

public class SnacksP extends javax.swing.JPanel {

    private JPanel panelContenedor;

    public SnacksP() {
        initComponents();
        cargarSnacksEnGrid();
    }

    public void cargarSnacksEnGrid() {
        List<Snacks> snacks = SnacksLoader.cargarSnacks();

        if (snacks != null && !snacks.isEmpty()) {
            panelContenedor.removeAll();
            panelContenedor.setLayout(new GridLayout(0, 3, 20, 25));

            for (Snacks snack : snacks) {
                JPanel tarjeta = new JPanel();
                tarjeta.setLayout(new BoxLayout(tarjeta, BoxLayout.Y_AXIS));
                tarjeta.setBackground(new Color(40, 40, 40));
                tarjeta.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
                tarjeta.setPreferredSize(new Dimension(260, 360));
                tarjeta.setAlignmentX(Component.CENTER_ALIGNMENT);

                try {
                    URL url = getClass().getResource("/" + snack.getImagen());
                    Image imagen = ImageIO.read(url);

                    if (imagen != null) {
                        Image imagenEscalada = imagen.getScaledInstance(220, 220, Image.SCALE_SMOOTH);
                        JLabel lblImagen = new JLabel(new ImageIcon(imagenEscalada));
                        lblImagen.setAlignmentX(Component.CENTER_ALIGNMENT);
                        lblImagen.setOpaque(false);
                        tarjeta.add(lblImagen);
                        tarjeta.add(Box.createVerticalStrut(15));
                    } else {
                        System.out.println("Imagen no encontrada: " + snack.getTitulo());
                    }
                } catch (Exception e) {
                    System.out.println("Error al cargar imagen para: " + snack.getTitulo());
                    e.printStackTrace();
                }

                JLabel lblTitulo = new JLabel(snack.getTitulo());
                lblTitulo.setForeground(Color.WHITE);
                lblTitulo.setFont(new Font("Arial", Font.BOLD, 18));
                lblTitulo.setAlignmentX(Component.CENTER_ALIGNMENT);

                JLabel lblPrecio = new JLabel("Precio: $" + snack.getPrecio());
                lblPrecio.setForeground(Color.LIGHT_GRAY);
                lblPrecio.setFont(new Font("Arial", Font.PLAIN, 16));
                lblPrecio.setAlignmentX(Component.CENTER_ALIGNMENT);

                JButton btnAgregar = new JButton("Agregar al carrito");
                btnAgregar.setAlignmentX(Component.CENTER_ALIGNMENT);
                btnAgregar.setBackground(new Color(255, 140, 0));
                btnAgregar.setForeground(Color.WHITE);
                btnAgregar.setFocusPainted(false);
                btnAgregar.setBorderPainted(false);
                btnAgregar.setFont(new Font("Arial", Font.BOLD, 14));
                btnAgregar.setCursor(new Cursor(Cursor.HAND_CURSOR));

              
                btnAgregar.addActionListener(e -> {
                    Compras compra = new Compras(snack.getTitulo(), snack.getPrecio(), 1);
                    new ComprasController().guardarCompra(compra);
                    JOptionPane.showMessageDialog(SnacksP.this, "Producto agregado al carrito.");
                });

                tarjeta.add(lblTitulo);
                tarjeta.add(Box.createVerticalStrut(5));
                tarjeta.add(lblPrecio);
                tarjeta.add(Box.createVerticalStrut(10));
                tarjeta.add(btnAgregar);
                panelContenedor.add(tarjeta);
            }

            panelContenedor.revalidate();
            panelContenedor.repaint();
        } else {
            System.out.println("No hay snacks para mostrar.");
        }
    }

    @SuppressWarnings("unchecked")
    private void initComponents() {
        JScrollPane scrollPane = new JScrollPane();
        panelContenedor = new javax.swing.JPanel();

        panelContenedor.setBackground(Color.BLACK);
        scrollPane.setViewportView(panelContenedor);
        scrollPane.getVerticalScrollBar().setUnitIncrement(20);

        setLayout(new BorderLayout());
        add(scrollPane, BorderLayout.CENTER);
    }
}