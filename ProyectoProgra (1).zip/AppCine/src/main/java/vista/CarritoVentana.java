package vista;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;
import controlador.ComprasController;
import modelo.Compras;

public class CarritoVentana extends JFrame {
    private JTable tabla;
    private DefaultTableModel modelo;
    private JButton btnRegresar, btnComprar;

    private Dashboard dashboard; 

    public CarritoVentana(Dashboard dashboard) {
        this.dashboard = dashboard;
        initUI(); 
    }


    private void initUI() {
        setTitle("Carrito");
        setSize(500, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        JLabel label = new JLabel("Carrito de Dulceria", JLabel.CENTER);
        label.setFont(new Font("Arial", Font.BOLD, 20));
        add(label, BorderLayout.NORTH);

        modelo = new DefaultTableModel(new String[]{"Producto", "Precio", "Cantidad", "Total"}, 0);
        tabla = new JTable(modelo);
        cargarCarrito();
        add(new JScrollPane(tabla), BorderLayout.CENTER);

        JPanel panelBotones = new JPanel();
        btnRegresar = new JButton("Regresar");
        btnComprar = new JButton("Ir a pagar");

        btnRegresar.addActionListener(e -> dispose());

        btnComprar.addActionListener(e -> {
            
           DatosPago datos = new DatosPago();
           datos.setVisible(true);
            
            dispose();
        });

        panelBotones.add(btnRegresar);
        panelBotones.add(btnComprar);
        add(panelBotones, BorderLayout.SOUTH);
    }

    private void cargarCarrito() {
        List<Compras> lista = new ComprasController().leerCarrito();
        for (Compras c : lista) {
            modelo.addRow(new Object[]{
                c.getProducto(),
                c.getPrecio(),
                c.getCantidad(),
                c.getTotal()
            });
        }
    }
}
