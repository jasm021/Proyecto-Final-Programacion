
package vista;

import DiseñoImagen.Esquinas;
import controlador.Promocion;
import controlador.PromocionLoader;
import javax.swing.*;
import java.awt.*;
import java.net.URL;
import java.util.List;
import javax.imageio.ImageIO;

public final class Promo extends javax.swing.JPanel {
    
private final JScrollPane scrollPane;

    
    public Promo() {
        
        initComponents();
        cargarPromocionesEnGrid();
        
        scrollPane = new JScrollPane(jPanel1);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        scrollPane.getVerticalScrollBar().setUnitIncrement(16); // velocidad scroll suave

        this.setLayout(new BorderLayout());
        this.remove(jPanel1); 
        this.add(scrollPane, BorderLayout.CENTER);

    }
     public void cargarPromocionesEnGrid() {
    List<Promocion> promociones = PromocionLoader.cargarPromociones();

    if (promociones != null && !promociones.isEmpty()) {
        jPanel1.removeAll();

        // GridLayout 0 filas, 2 columnas, espacios entre tarjetas
        jPanel1.setLayout(new GridLayout(0, 2, 15, 15));

        for (Promocion proms : promociones) {
            JPanel tarjeta = new JPanel(new BorderLayout(10, 10));

            tarjeta.setBackground(Color.DARK_GRAY);
            tarjeta.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(Color.WHITE, 2),
                BorderFactory.createEmptyBorder(15, 15, 15, 15)
            ));

            // Tamaño mayor para evitar que se corte el contenido
            tarjeta.setPreferredSize(new Dimension(450, 280));

            try {
                URL url = getClass().getResource(proms.getImagen());
                Image imagen = ImageIO.read(url);

                if (imagen != null) {
                    JLabel lblImagen = new JLabel(new ImageIcon(Esquinas.redondearEsquinas(imagen, 210, 200, 30)));
                    tarjeta.add(lblImagen, BorderLayout.WEST);
                } else {
                    System.out.println("La imagen es null para " + proms.getTitulo());
                }
            } catch (Exception e) {
                System.out.println("Error al cargar imagen para: " + proms.getTitulo());
            }

            JPanel panelTextos = new JPanel();
            panelTextos.setLayout(new BoxLayout(panelTextos, BoxLayout.Y_AXIS));
            panelTextos.setBackground(Color.BLACK);
            panelTextos.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));

            JLabel lblTitulo = new JLabel(proms.getTitulo());
            lblTitulo.setForeground(Color.WHITE);
            lblTitulo.setFont(new Font("Arial", Font.BOLD, 32));
            lblTitulo.setAlignmentX(Component.CENTER_ALIGNMENT);

            JLabel lblDetalles = new JLabel(proms.getDetalles());
            lblDetalles.setForeground(Color.WHITE);
            lblDetalles.setFont(new Font("Arial", Font.PLAIN, 12));
            lblDetalles.setAlignmentX(Component.CENTER_ALIGNMENT);

            JLabel lblAnterior = new JLabel("Precio Anterior : $" + proms.getprecioAnterior());
            lblAnterior.setForeground(Color.LIGHT_GRAY);
            lblAnterior.setFont(new Font("Arial", Font.BOLD, 17));
            lblAnterior.setAlignmentX(Component.CENTER_ALIGNMENT);

            JLabel lblPromocion = new JLabel("Precio Promoción: $ " + proms.getprecioPromocion());
            lblPromocion.setForeground(Color.LIGHT_GRAY);
            lblPromocion.setFont(new Font("Arial", Font.BOLD, 18));
            lblPromocion.setAlignmentX(Component.CENTER_ALIGNMENT);

            JButton btnAgregar = new JButton("Agregar al carrito");
            btnAgregar.setAlignmentX(Component.CENTER_ALIGNMENT);
            btnAgregar.setBackground(new Color(255, 140, 0));
            btnAgregar.setForeground(Color.WHITE);
            btnAgregar.setFocusPainted(false);
            btnAgregar.setBorderPainted(false);
            btnAgregar.setFont(new Font("Arial", Font.BOLD, 14));
            btnAgregar.setCursor(new Cursor(Cursor.HAND_CURSOR));

            panelTextos.add(lblTitulo);
            panelTextos.add(Box.createVerticalStrut(8));
            panelTextos.add(lblDetalles);
            panelTextos.add(Box.createVerticalStrut(10));
            panelTextos.add(lblAnterior);
            panelTextos.add(Box.createVerticalStrut(15));
            panelTextos.add(lblPromocion);
            panelTextos.add(Box.createVerticalStrut(20));
            panelTextos.add(btnAgregar);

            tarjeta.add(panelTextos, BorderLayout.CENTER);

            jPanel1.add(tarjeta);
        }

        jPanel1.revalidate();
        jPanel1.repaint();
    } else {
        System.out.println("No hay Promociones para mostrar.");
    }
}


    
    
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollBar2 = new javax.swing.JScrollBar();
        jPanel1 = new javax.swing.JPanel();

        jPanel1.setBackground(new java.awt.Color(0, 0, 0));
        jPanel1.setLayout(new java.awt.GridLayout(0, 2));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 1040, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 512, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollBar jScrollBar2;
    // End of variables declaration//GEN-END:variables
}
