
package DiseñoImagen;

import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RenderingHints;
import java.awt.geom.RoundRectangle2D;
import java.awt.image.BufferedImage;

public class Esquinas {
    
    public static BufferedImage redondearEsquinas(Image imagenOriginal,int ancho,int alto, int radioEsquina){
        
       BufferedImage imgRedon= new BufferedImage(ancho,alto,BufferedImage.TYPE_INT_ARGB);
       
       Graphics2D g2 = imgRedon.createGraphics();
       
       g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
       
       RoundRectangle2D round = new RoundRectangle2D.Float(0,0,ancho,alto,radioEsquina,radioEsquina);
       g2.setClip(round);
       g2.drawImage(imagenOriginal,0,0,ancho,alto,null);
       
       g2.dispose();
       
       return imgRedon;
        
    }
}
