package modelo;

import java.awt.Color;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JLabel;

public class ManejarButacas {
    
    public enum Estado { DISPONIBLE, SELECCIONADA, RESERVADA }

    private Estado estado;
    private final JLabel label;
    private final String codigo;

    public ManejarButacas(JLabel label, String codigo) {
        this.label = label;
        this.codigo = codigo;
        this.estado = Estado.DISPONIBLE;

        configurarLabel();
        agregarEventoClick();
    }

    private void configurarLabel() {
        label.setText(codigo);
        label.setForeground(Color.WHITE);
        label.setToolTipText("Butaca " + codigo);
    }

    private void agregarEventoClick() {
        label.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (estado == Estado.DISPONIBLE) {
                    setEstado(Estado.SELECCIONADA);
                } else if (estado == Estado.SELECCIONADA) {
                    setEstado(Estado.DISPONIBLE);
                }
            }
        });
    }
    Color miColor = new Color(0,102,153);
    public void setEstado(Estado nuevoEstado) {
        this.estado = nuevoEstado;
        switch (estado) {
            case DISPONIBLE -> label.setBackground(miColor);
            case SELECCIONADA -> label.setBackground(Color.ORANGE);
            case RESERVADA -> label.setBackground(Color.RED);
        }
    }

    public Estado getEstado() {
        return estado;
    }

    public void reservar() {
        if (estado == Estado.SELECCIONADA) {
            setEstado(Estado.RESERVADA);
        }
    }

    public boolean estaSeleccionada() {
        return estado == Estado.SELECCIONADA;
    }

    public boolean estaReservada() {
        return estado == Estado.RESERVADA;
    }

    public String getCodigo() {
        return codigo;
    }
}
