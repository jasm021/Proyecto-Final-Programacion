package controlador;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Type;
import java.util.List;

public class PeliculaLoader {

    public static List<Pelicula> cargarPeliculas() {
        try {
            InputStream is = PeliculaLoader.class.getResourceAsStream("/pelis.json");
            InputStreamReader reader = new InputStreamReader(is, "UTF-8");

            Type tipoLista = new TypeToken<List<Pelicula>>(){}.getType();
            List<Pelicula> peliculas = new Gson().fromJson(reader, tipoLista);

            reader.close();
            return peliculas;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
