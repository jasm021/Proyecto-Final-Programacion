package controlador;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Type;
import java.util.List;

public class PromocionLoader {

    public static List<Promocion> cargarPromociones() {
        try {
            InputStream is = PromocionLoader.class.getResourceAsStream("/promociones.json");
            InputStreamReader reader = new InputStreamReader(is, "UTF-8");

            Type tipoLista = new TypeToken<List<Promocion>>(){}.getType();
            List<Promocion> promociones = new Gson().fromJson(reader, tipoLista);

            reader.close();
            return promociones;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
