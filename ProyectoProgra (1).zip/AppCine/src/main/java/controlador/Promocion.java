
package controlador;

public class Promocion {
    
    private String imagen;
    private String titulo;
    private String detalles;
    private float precioAnterior;
    private float precioPromocion;
    


    public String getImagen() {
        return imagen;
    }
    
    public String getTitulo() {
        return titulo;
    }
    public String getDetalles(){
        return detalles;
    }

    public float getprecioAnterior() {
        return precioAnterior;
    }

    public float getprecioPromocion() {
        return precioPromocion;
    }

}