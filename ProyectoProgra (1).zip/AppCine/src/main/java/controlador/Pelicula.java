
package controlador;


public class Pelicula {
    
    private String titulo;
    private String imagen;
    private String genero;
    private int duracion;
    private String imagenUrl;
    private String sinopsis;
    
    public String getSinopsis() {
        return sinopsis;
    }
    public String getTitulo() {
        return titulo;
    }

    public String getImagen() {
        return imagen;
    }

    public String getGenero() {
        return genero;
    }

    public int getDuracion() {
        return duracion;
    }

    public String getImagenUrl() {
        return imagenUrl;
    }
    
    
}
