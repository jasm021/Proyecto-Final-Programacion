
package controlador;

import java.io.FileWriter;
import java.io.PrintWriter;
import javax.swing.JOptionPane;


public class guardarusuarios {
    
    
    public void trasnferir (Usuarios user){
        
        try{
            
            FileWriter escritor = new FileWriter("usuarios.txt");
            PrintWriter pw = new PrintWriter(escritor);
            
            pw.println(user.getNombre()+","+user.getCedula()+","+user.getCorreo()+","+user.getContraseña());
            pw.close();
            
            JOptionPane.showMessageDialog(null,"Usuario registrado exitosamente");
            
            
        } catch(Exception e){
            
            JOptionPane.showMessageDialog(null,"Ha ocurrido un error");
            
        }
        
        
    }
    
}
