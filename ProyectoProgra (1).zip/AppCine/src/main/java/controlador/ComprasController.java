
package controlador;

import java.io.*;
import java.util.*;
import modelo.Compras;

/**
 *
 * @author ismae
 */
public class ComprasController {
    private final String ARCHIVO = "carrito.txt";

    // Guarda una compra en el archivo del carrito
    public void guardarCompra(Compras compra) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(ARCHIVO, true))) {
            writer.write(compra.toString());
            writer.newLine();
        } catch (IOException e) {
            System.err.println("Error al guardar en el carrito:");
            e.printStackTrace();
        }
    }

    // Lee todas las compras guardadas en el archivo del carrito
    public List<Compras> leerCarrito() {
        List<Compras> lista = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(ARCHIVO))) {
            String line;
            while ((line = reader.readLine()) != null) {
                lista.add(Compras.fromString(line));
            }
        } catch (IOException e) {
            System.err.println("Error al leer el carrito:");
            e.printStackTrace();
        }
        return lista;
    }
}
