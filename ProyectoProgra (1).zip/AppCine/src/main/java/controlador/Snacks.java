
package controlador;

public class Snacks {
    
    private String imagen;
    private String titulo;
    private float precio;
    
    public Snacks(String imagen, String titulo, float precio){
        this.imagen = imagen;
        this.titulo = titulo;
        this.precio = precio;
        
    }
    
    
    


    public String getImagen() {
        return imagen;
    }
    
    public String getTitulo() {
        return titulo;
    }
 
    public float getPrecio() {
        return precio;
    }

}
