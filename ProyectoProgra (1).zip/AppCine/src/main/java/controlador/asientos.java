
package controlador;
import java.util.ArrayList;

public class asientos {
    
    
    private ArrayList<String> listaAsientos;

    public void setListaAsientos(ArrayList<String> listaAsientos) {
        this.listaAsientos = listaAsientos;
    }

    public ArrayList<String> getListaAsientos() {
        return listaAsientos;
    }
}

    
    
    
