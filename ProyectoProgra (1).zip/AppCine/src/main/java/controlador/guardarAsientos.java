
package controlador;

import java.io.FileWriter;
import java.io.PrintWriter;
import javax.swing.JOptionPane;    
import java.io.BufferedWriter;
import java.io.IOException;
import java.util.ArrayList;
public class guardarAsientos {

    
    public void reservarAsientos(asientos asiento) {
        ArrayList<String> lista = asiento.getListaAsientos();
        try {
            BufferedWriter writer = new BufferedWriter(new FileWriter("asientos_reservados.txt", true)); // true = append
            for (String nombreAsiento : lista) {
                writer.write(nombreAsiento);
                writer.newLine();
            }
            writer.close();
        } catch (IOException e) {
            System.out.println("Error al guardar los asientos: " + e.getMessage());
        }
    }
}

    

