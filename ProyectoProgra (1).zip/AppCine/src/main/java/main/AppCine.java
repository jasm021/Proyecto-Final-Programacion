
package main;

import vista.Dashboard;


public class AppCine {

    public static void main(String[] args) {
        
        Dashboard v1 = new Dashboard();
        
        v1.setVisible(true);
        
    }
}
